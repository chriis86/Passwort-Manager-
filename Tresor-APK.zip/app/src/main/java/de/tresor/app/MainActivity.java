package de.tresor.app;

import android.annotation.SuppressLint;
import android.content.ClipData;
import android.content.ClipDescription;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyPermanentlyInvalidatedException;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

public class MainActivity extends AppCompatActivity {

    private static final String KEY_ALIAS = "tresor_bio_key";
    private static final String HOST = "appassets.androidplatform.net";
    private static final int REQ_OPEN = 1;
    private static final int REQ_SAVE = 2;

    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private String pendingSave;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Keine Screenshots / keine Vorschau im App-Wechsler
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception ignored) { }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                try {
                    startActivityForResult(i, REQ_OPEN);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidTresor");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                web.evaluateJavascript("window.__back ? window.__back() : false", value -> {
                    if (!"true".equals(value)) moveTaskToBack(true);
                });
            }
        });

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl("https://" + HOST + "/assets/index.html");
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    @Override
    protected void onStop() {
        super.onStop();
        js("window.__appHidden && window.__appHidden()");
    }

    @Override
    protected void onStart() {
        super.onStart();
        js("window.__appVisible && window.__appVisible()");
    }


    @SuppressWarnings("deprecation")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OPEN) {
            if (fileCallback != null) {
                Uri[] result = null;
                if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
                fileCallback.onReceiveValue(result);
                fileCallback = null;
            }
        } else if (requestCode == REQ_SAVE) {
            String content = pendingSave;
            pendingSave = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && content != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                    if (os == null) throw new Exception("Kein Zugriff");
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                    toast("Backup gespeichert ✔");
                } catch (Exception e) {
                    toast("Backup konnte nicht gespeichert werden");
                }
            }
        }
    }

    /* ---------------- Hilfen ---------------- */

    private void js(String code) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void toast(String msg) {
        js("window.__toast && window.__toast(" + JSONObject.quote(msg) + ")");
    }

    private void bioResult(boolean ok, String a, String b) {
        js("window.__bioCb && window.__bioCb(" + ok + "," + JSONObject.quote(a == null ? "" : a)
                + "," + JSONObject.quote(b == null ? "" : b) + ")");
    }

    private static String b64(byte[] d) {
        return Base64.encodeToString(d, Base64.NO_WRAP);
    }

    private static byte[] unb64(String s) {
        return Base64.decode(s, Base64.NO_WRAP);
    }

    /* ---------------- Android-Keystore ---------------- */

    private SecretKey createKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS);

        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(true)
                .setInvalidatedByBiometricEnrollment(true);
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG);
        }
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        kg.init(b.build());
        return kg.generateKey();
    }

    private SecretKey getKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        return (SecretKey) ks.getKey(KEY_ALIAS, null);
    }

    private void deleteKey() {
        try {
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS);
        } catch (Exception ignored) { }
    }

    private interface CipherDone {
        void run(Cipher c) throws Exception;
    }

    private void prompt(String title, Cipher cipher, CipherDone done) {
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle("Finger auf den Sensor legen")
                .setNegativeButtonText("Abbrechen")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .build();

        BiometricPrompt bp = new BiometricPrompt(this, ContextCompat.getMainExecutor(this),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        try {
                            BiometricPrompt.CryptoObject co = result.getCryptoObject();
                            if (co == null || co.getCipher() == null) throw new Exception("Kein Schlüssel");
                            done.run(co.getCipher());
                        } catch (Exception e) {
                            bioResult(false, "Entschlüsseln fehlgeschlagen. Bitte Master-Passwort nutzen.", null);
                        }
                    }

                    @Override
                    public void onAuthenticationError(int code, @NonNull CharSequence msg) {
                        bioResult(false, msg.toString(), null);
                    }
                });
        bp.authenticate(info, new BiometricPrompt.CryptoObject(cipher));
    }

    /* ---------------- Brücke zum JavaScript ---------------- */

    private class Bridge {

        @JavascriptInterface
        public boolean bioAvailable() {
            return BiometricManager.from(MainActivity.this)
                    .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                    == BiometricManager.BIOMETRIC_SUCCESS;
        }

        @JavascriptInterface
        public void bioEnroll(String rawKeyB64) {
            runOnUiThread(() -> {
                try {
                    final byte[] raw = unb64(rawKeyB64);
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.ENCRYPT_MODE, createKey());
                    prompt("Fingerabdruck einrichten", c, cipher -> {
                        byte[] ct = cipher.doFinal(raw);
                        bioResult(true, b64(cipher.getIV()), b64(ct));
                    });
                } catch (Exception e) {
                    bioResult(false, "Fingerabdruck konnte nicht eingerichtet werden. Ist ein Fingerabdruck im Handy gespeichert?", null);
                }
            });
        }

        @JavascriptInterface
        public void bioUnlock(String ivB64, String ctB64) {
            runOnUiThread(() -> {
                try {
                    SecretKey key = getKey();
                    if (key == null) throw new KeyPermanentlyInvalidatedException();
                    final byte[] ct = unb64(ctB64);
                    Cipher c = Cipher.getInstance("AES/GCM/NoPadding");
                    c.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, unb64(ivB64)));
                    prompt("Passwort-Manager entsperren", c, cipher -> {
                        byte[] raw = cipher.doFinal(ct);
                        bioResult(true, b64(raw), null);
                    });
                } catch (KeyPermanentlyInvalidatedException e) {
                    deleteKey();
                    bioResult(false, "Die Fingerabdrücke im Handy wurden geändert. Bitte mit Master-Passwort entsperren und Fingerabdruck in den Einstellungen neu einrichten.", null);
                } catch (Exception e) {
                    bioResult(false, "Fingerabdruck nicht möglich. Bitte Master-Passwort nutzen.", null);
                }
            });
        }

        @JavascriptInterface
        public void bioRemove() {
            deleteKey();
        }

        @JavascriptInterface
        public void copy(String text) {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm == null) return;
                ClipData clip = ClipData.newPlainText("Passwort", text);
                if (Build.VERSION.SDK_INT >= 24) {
                    PersistableBundle extras = new PersistableBundle();
                    // Android 13+: Inhalt wird in der Vorschau versteckt
                    extras.putBoolean(Build.VERSION.SDK_INT >= 33
                            ? ClipDescription.EXTRA_IS_SENSITIVE
                            : "android.content.extra.IS_SENSITIVE", true);
                    clip.getDescription().setExtras(extras);
                }
                cm.setPrimaryClip(clip);
            });
        }

        @JavascriptInterface
        public void clearClipboard() {
            runOnUiThread(() -> {
                ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                if (cm == null) return;
                if (Build.VERSION.SDK_INT >= 28) cm.clearPrimaryClip();
                else cm.setPrimaryClip(ClipData.newPlainText("", ""));
            });
        }

        @JavascriptInterface
        public void saveFile(String name, String content) {
            runOnUiThread(() -> {
                pendingSave = content;
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    pendingSave = null;
                    toast("Speichern nicht möglich");
                }
            });
        }
    }
}
