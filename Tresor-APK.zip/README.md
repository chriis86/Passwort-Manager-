# Mein Passwort-Manager für Android

- Verschlüsselt mit AES-256 (Master-Passwort, PBKDF2 mit 310.000 Runden)
- Entsperren per Fingerabdruck (Android-Keystore + BiometricPrompt)
- Passwort-Generator, Suche, Kopieren (Zwischenablage wird nach 30 s geleert)
- Auto-Sperre, keine Screenshots, komplett offline – keine Internet-Berechtigung
- Verschlüsseltes Backup exportieren/importieren

## APK bauen (GitHub Actions)
1. Neues **privates** Repo auf GitHub anlegen und alle Dateien hochladen.
2. Tab **Actions** → Workflow „APK bauen“ läuft automatisch (ca. 3–5 Min.).
3. Fertigen Lauf öffnen → unten bei **Artifacts** „Tresor-APK“ herunterladen → ZIP entpacken → `app-release.apk` installieren.

Hinweis: `app/tresor.keystore` ist der Signaturschlüssel. Nicht löschen – sonst lassen sich Updates nicht über die alte Version installieren.
